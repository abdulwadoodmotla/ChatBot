import sqlite3 as sql
conn = sql.connect('Healthcare.sql')

onlineConsultation=["virtual", "online", "not face to face"]
symtomChecking=["symtoms","symptom"]

yes=["yes", "yeah", "ok", "sure", "i guess"]
no=["no", "nah", "i dont want to", "i dont think so"]

femalesynonyms=["female", "girl", "woman"]
malesynonyms=["male","guy","man"]

week=["Saturday" , "Monday", "Tuesday" ,"Wednesday", "Friday"]
weekend=["Sunday"]

RachelGreen={
        "Name" : "Rachel Green",
        "Type Of Doctor": "Pediatrician",
        "Gender": "Female",
        "Hospital": "Global Health Hospital",
        "Contact Details": "055432851021",
        "Available time": ["09:00-13:00", "18:00-22:00"]
    }

JoeyTribbiani={
        "Name" : "Joey Tribbiani",
        "Type Of Doctor": "Pediatrician",
        "Gender": "Male",
        "Hospital": "Heal and Health Hospital",
        "Contact Details": "0556892341",
        "Available time": ["05:00-09:00", "13:00-18:00"]
    }
    
PhoebeBuffay={
        "Name" : "Phoebe Buffay",
        "Type Of Doctor": "General Physician",
        "Gender": "Female",
        "Hospital": "Global Health Hospital",
        "Contact Details": "05586925145",
        "Available time": ["09:00-13:00", "18:00-22:00"]
    }
ChandlerBing={
        "Name" : "Chandler Bing",
        "Type Of Doctor": "General Physician",
        "Gender": "Male",
        "Hospital": "Heal and Health Hospital",
        "Contact Details" : "05568972586",
        "Available time": ["05:00-09:00", "13:00-18:00"]
    }



name= input ("Hello. What is your name? ")
provideHelp= input("How can I help you today," + name + "? ") 
removePunctuation= provideHelp.rstrip("?.,")
makeLowerCase= removePunctuation.lower()
string=makeLowerCase.split()

def appointment(yesOrNo):
    if yesOrNo in no:
        out= print("Would you like assisstance for something else? ")
    elif yesOrNo in yes:
        day=input("What day would you like your appointment to be booked? ")
        if day in weekend:
            out= input("It is a weekend. Please choose another day.")
        elif day not in week:
            out= input("Please provide an option of a day in the week.")
        elif day in week:
            out= print("You're appointment has been confirmed for " + day + ".")
        
def doctorDetails(specialist, gender):
    if specialist=="pediatrician":
        for s in gender:
            for word in femalesynonyms:
                if s == word:
                    doctor=print(RachelGreen)
            for word in malesynonyms:
                if s == word:
                    doctor= print(JoeyTribbiani)
    elif specialist=="general practitioner":
        for s in gender:
            for word in malesynonyms:
                if s==word:
                    doctor=print(ChandlerBing) 
            for word in femalesynonyms:
                if s==word:
                    doctor= print(PhoebeBuffay)
    arrangeAppointmentConfirmation=input("Would you like to arrange an appointment?")
    appointment(arrangeAppointmentConfirmation)
    return doctor

def confirm(age):
    if age< "18":
        specialist = "pediatrician"
        print("Visiting a " + specialist + " would be better as you are a child.")
    if age>= "18":
        specialist = "general practitioner"
        print("Visiting a " + specialist + " would be better as you are an adult.") 
    answer=input ("What is your gender preference?")    
    cleanString= answer.rstrip("?.,")
    sentence= cleanString.lower() 
    gender=sentence.split()
    doctorDetails(specialist, gender)                         
    return specialist

def functions():
    for word in string:
        for options in onlineConsultation:
            if options==word:
                ask("age")        
       
               
def ask(personaldetails):
    if personaldetails=="name":
        x=input("What is your name? ")
        name=x.capitalize()
        out= name
    elif personaldetails=="medicalhistory":
        medicalhistory=(input("Do you have a past medical history? "))
        out=medicalhistory
    elif personaldetails=="age":    
        age=input("What is your age?")
        confirm(age)
        out=age
    return out

def department(consultation):
    out=Department
    print("If you beleive you may be suffering from " + Diagnosis + ", I prefer you to visit the " + Department + " department.")
    return out

#Determing type of consultation the patient should receive and the department they should visit depending on the risk factor
def consultation(Risk):
    if Risk<=2:
        consultation= "online consultation"
        print("You're situation doesn't seem too serious. I would recommend you to have an " + consultation + "." )  
    elif Risk<=4:
        consultation= "physical consultation"
        print("You're situation seems a little serious. You should have a " + consultation + ".")
    else:
        consultation= "emergency"
        print("Your condition seems extremely serious. You should go to the " + consultation + " immediately." )
    department(consultation)
    return consultation

# providing more symptoms related to the diagnosis for the patient to check which they relate to better
def moreSymptoms(Diagnosis):
    allSymptoms=conn.execute('''SELECT s.Description FROM Diagnosis_Information d, Symptoms s, Symptom_Checking sc WHERE s.Symptom_ID= sc.Symptom_ID AND sc.Diagnosis_ID=d.Diagnosis_ID AND d.Diagnosis=? GROUP BY d.Diagnosis''',(Diagnosis,))
    for row in allSymptoms:
        print("Symptoms may include: " '%s' %row)    
    consultation(Risk)
    return allSymptoms

#telling the patient the condition they might have
def symtomChecker(Diagnosis):
    print ("You may have " + Diagnosis + ".")
    moreSymptoms(Diagnosis)
    return Diagnosis

functions()

#asking for the patients symtoms
question=input("What are your symptoms? ")

#fetching required data from the database
try:
   #SQL query
  cursor=conn.execute('''SELECT * FROM Diagnosis_Information d, Symptoms s, Symptom_Checking sc WHERE s.Symptom_ID= sc.Symptom_ID AND sc.Diagnosis_ID=d.Diagnosis_ID AND s.Description=? ''',(question,))
   # Fetch all the rows from the Departments table
  results = cursor.fetchall()
  for row in results:
        Diagnosis_ID= row[0]
        Diagnosis= row[1]
        Risk = row[2]
        Department = row[3]
        symtomChecker(Diagnosis)
except TypeError:
        print ("I'm sorry, I cannot recognise your symptoms. Please consult a general practitioner")
       


ask("age")


        

